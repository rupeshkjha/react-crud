import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';


declare var DSXDFUtil: any;

class App extends Component {
    componentDidMount() {
       
        //  this.state = { seconds: 0 };
        
        var dfp: any = DSXDFUtil.createDSXDFUtil();
        var cdiv = document.getElementById("center");
        cdiv.style.backgroundColor='white'; // React's style does not workl
        dfp.addFixedPanel(cdiv, DSXDFUtil.fixedCenter);

        var dfwa: any = dfp.createDFPanel("Panel", "mydfa");
        dfwa.addContentDiv(document.getElementById("mydf"));
        dfwa.initLayout(300, 50, 400, 200, 0);

        var dfwb: any = dfp.createDFPanel("React Dock & Float Panel", "mydfa");
        var another = document.getElementById("reactdf");
        dfwb.addContentDiv(another);
        another.style.backgroundColor='white'; // React's style does not workl
        dfwb.initLayout(300, 50, 400, 200, 1);
      
    }
    render() {
        var st ={backgroudColor:'red'};
        return (
    
        <div className="App">
            <div id = 'center' style={st}>
              <a href="../JavaScriptDockFloatSimpleDemo.html"> Simple Demo Using div Elements</a><br />
                <br />
                <a href="../JavaScriptDockFloatSimplePersistDemo.html"> A Demo Showing How to Persist States</a><br />
                <br />
                <a href="../JavaScriptDockFloatSimpleLayoutDemo.html"> A Demo Showing How to Create a Layout</a><br />
                <br />
                <a href="../JavaScriptDockFloatIFrameDemo.html"> A Demo Showing How to Make IFrame Dockable & Floatable</a><br />
                <br />
                <a href="../JavaScriptDockFloatFixedSidesDemo.html"> A Demo Showing How to Create Fixed Panels</a> <br />
                <br />
                <a href = "../AngularJS/index.html"> A Demo Showing How to Integrate with Angular JS(2)</a><br />
                <br />
                <a href="../../index.htm"><b>Home Page</b></a><br />
                <br />
                <hr />
                This page shows how to integrate dsxDockFloarPro framework with ReactJS.  Click <a href="www.htmldockfloat.com/dsxDockFloatProWithReactJS.zip"> here </a> to download the source codes.
           </div>
            <div id='mydf' style={{overflow:'auto'}}>You can put any other ReactJS contents here!</div>
            <div id='reactdf' style={{overflow:'auto'}}>
                <header className="App-header">
                  <img src={logo} className="App-logo" alt="logo" />
                  <h1 className="App-title">Welcome to React</h1>
                </header>
                <p className="App-intro">
                  To get started, edit <code>src/App.js</code> and save to reload.
                </p>
            </div>
      </div>
      
    );
  }
}

export default App

